package com.pacha.assistant

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.AlarmClock
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var notesView: TextView
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private val audioRequest = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("pacha_memory", MODE_PRIVATE)
        tts = TextToSpeech(this, this)
        buildScreen()
        showNotes()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 30, 28, 24)
            setBackgroundColor(0xFF10111B.toInt())
        }
        val title = TextView(this).apply {
            text = "PACHA"
            textSize = 32f
            setTextColor(0xFFBBA4FF.toInt())
            gravity = android.view.Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Tu asistente personal"
            textSize = 15f
            setTextColor(0xFFE7E4F2.toInt())
            gravity = android.view.Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Hola. Soy Pacha. Escribe o pulsa Hablar."
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 24, 0, 16)
        }
        input = EditText(this).apply {
            hint = "Escribe una orden..."
            setHintTextColor(0xFFAAA6B8.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setSingleLine(false)
            minLines = 2
            setBackgroundColor(0xFF242536.toInt())
            setPadding(14, 10, 14, 10)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(status)
        root.addView(input, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        root.addView(makeButton("Hablar", 0xFF6D4AFF) { listen() })
        root.addView(makeButton("Ejecutar orden", 0xFF40366A) { handleCommand(input.text.toString()) })
        root.addView(makeButton("Guardar dato", 0xFF285A56) { saveNote(input.text.toString()) })
        root.addView(makeButton("Abrir WhatsApp", 0xFF1F6A49) { openPackage("com.whatsapp") })
        root.addView(makeButton("Abrir YouTube", 0xFF8E2830) { openPackage("com.google.android.youtube") })
        root.addView(makeButton("Abrir Chrome", 0xFF355C9B) { openPackage("com.android.chrome") })
        root.addView(makeButton("Crear alarma", 0xFF514A2C) { createAlarm(input.text.toString()) })
        val notesTitle = TextView(this).apply {
            text = "DATOS GUARDADOS"
            textSize = 14f
            setTextColor(0xFFBBA4FF.toInt())
            setPadding(0, 16, 0, 6)
        }
        notesView = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFFE7E4F2.toInt())
        }
        root.addView(notesTitle)
        root.addView(notesView)
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun makeButton(label: String, color: Int, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(color))
            setOnClickListener { action() }
        }
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts?.language = Locale("es", "CR")
        }
    }

    private fun speak(text: String) {
        status.text = text
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "pacha_reply")
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Este teléfono no tiene disponible el reconocimiento de voz.")
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), audioRequest)
            return
        }
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-CR")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla con Pacha")
            }
            speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "Te escucho..." }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { status.text = "Procesando..." }
                override fun onError(error: Int) { status.text = "No pude entenderte. Pulsa Hablar e inténtalo de nuevo." }
                override fun onResults(results: Bundle?) {
                    val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    input.setText(phrase)
                    handleCommand(phrase)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            speechRecognizer?.startListening(intent)
        } catch (_: Exception) {
            speak("No pude iniciar el micrófono. Revisa los permisos.")
        }
    }

    private fun handleCommand(raw: String) {
        val cmd = raw.trim().lowercase(Locale("es", "CR"))
        if (cmd.isBlank()) { speak("Dime qué necesitas."); return }
        when {
            cmd.startsWith("pacha") -> {
                val cleaned = cmd.removePrefix("pacha").trim(' ', ',', '.', ':')
                handleCommand(cleaned)
            }
            cmd.contains("abre whatsapp") || cmd == "whatsapp" -> openPackage("com.whatsapp")
            cmd.contains("abre youtube") || cmd == "youtube" -> openPackage("com.google.android.youtube")
            cmd.contains("abre chrome") || cmd.contains("abre internet") || cmd == "chrome" -> openPackage("com.android.chrome")
            cmd.startsWith("guarda ") || cmd.startsWith("recuerda ") || cmd.startsWith("anota ") -> {
                val note = raw.substringAfter(" ", "").trim()
                if (note.isNotBlank()) saveNote(note) else speak("Dime qué dato guardo.")
            }
            cmd.contains("alarma") -> createAlarm(raw)
            cmd.contains("qué puedes hacer") || cmd.contains("que puedes hacer") || cmd == "ayuda" ->
                speak("Puedo abrir algunas aplicaciones, guardar datos, crear alarmas y responder con voz. Esta es una primera versión.")
            cmd.contains("hola") -> speak("¡Hola! Soy Pacha. ¿Qué hacemos?")
            else -> speak("Todavía no tengo conectada una inteligencia artificial para responder cualquier pregunta. Puedo abrir WhatsApp, YouTube, Chrome, guardar datos o crear alarmas.")
        }
    }

    private fun openPackage(packageName: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            try { startActivity(launch); speak("Abriendo la aplicación.") }
            catch (_: Exception) { speak("No pude abrir esa aplicación.") }
        } else speak("No encuentro esa aplicación instalada.")
    }

    private fun saveNote(text: String) {
        if (text.isBlank()) { speak("Escribe o di el dato que quieres guardar."); return }
        val old = prefs.getString("notes", "").orEmpty()
        val updated = if (old.isBlank()) "• $text" else "$old\n• $text"
        prefs.edit().putString("notes", updated).apply()
        showNotes()
        input.setText("")
        speak("Listo. Guardé ese dato en este teléfono.")
    }

    private fun showNotes() {
        notesView.text = prefs.getString("notes", "Todavía no has guardado datos.")
    }

    private fun createAlarm(text: String) {
        val regex = Regex("""(?i)(?:a las|para las)\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)?""")
        val match = regex.find(text)
        if (match == null) {
            speak("Para crear una alarma, escribe por ejemplo: alarma a las 7:30 am.")
            return
        }
        var hour = match.groupValues[1].toIntOrNull() ?: 7
        val minute = match.groupValues[2].toIntOrNull() ?: 0
        val suffix = match.groupValues[3].lowercase()
        if (suffix == "pm" && hour < 12) hour += 12
        if (suffix == "am" && hour == 12) hour = 0
        if (hour !in 0..23 || minute !in 0..59) {
            speak("Esa hora no parece válida.")
            return
        }
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, "Alarma creada por Pacha")
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
        }
        try { startActivity(intent) }
        catch (_: ActivityNotFoundException) { speak("No encontré una aplicación de reloj compatible.") }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioRequest && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            listen()
        } else if (requestCode == audioRequest) {
            speak("Necesito permiso del micrófono para escucharte.")
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
