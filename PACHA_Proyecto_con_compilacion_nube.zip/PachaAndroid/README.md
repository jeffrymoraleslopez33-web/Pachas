# PACHA — prototipo Android y compilación desde el celular

## Qué incluye
- Interfaz nativa en español.
- Voz bajo demanda con el botón Hablar.
- Respuestas habladas.
- Abrir WhatsApp, YouTube y Chrome si están instalados.
- Notas locales.
- Abrir el reloj para crear una alarma.

## Limitaciones
Este prototipo todavía no incluye IA conversacional conectada, activación permanente por frase, envío automático de WhatsApp, lectura de notificaciones ni desbloqueo del teléfono. No está compilado en este ZIP: el APK debe generarse primero.

## Compilar sin computadora usando GitHub Actions
Este repositorio incluye un flujo de GitHub Actions en `.github/workflows/build.yml` que intenta compilar un APK de depuración en la nube.

1. En el navegador del teléfono, entra a https://github.com y crea una cuenta o inicia sesión.
2. Crea un repositorio nuevo llamado `PachaAndroid`. Para el primer intento, selecciona público solo si te sientes cómodo con que el código sea visible; nunca subas contraseñas, tokens, claves API ni datos personales.
3. Sube el contenido de esta carpeta al repositorio conservando la estructura de carpetas, especialmente `.github/workflows/build.yml`.
4. Abre la pestaña **Actions** del repositorio. Si te pide habilitar Actions, actívalo.
5. En **Build PACHA APK**, pulsa **Run workflow**.
6. Espera a que termine. Si aparece una marca verde, abre la ejecución y baja hasta **Artifacts**.
7. Descarga `PACHA-debug-APK`, descomprime el ZIP descargado y localiza `app-debug.apk`.
8. Abre el APK desde Descargas. Si Android lo solicita, permite instalar aplicaciones desde ese navegador/gestor de archivos y confirma la instalación.

Si el flujo falla, abre el registro de la ejecución y revisa el primer error en rojo. El proyecto puede necesitar ajustes según la versión de Gradle/SDK y el entorno.

## Importante
- El APK de depuración no es una publicación oficial de Google Play.
- No habilites permisos de accesibilidad o notificaciones para aplicaciones desconocidas sin entenderlos.
- Esta versión no desbloquea el teléfono, no escucha permanentemente y no ejecuta acciones ocultas.
- La IA conversacional real requiere integrar un proveedor de IA. Las claves privadas no deben guardarse dentro de la aplicación Android; se necesita un backend seguro o un diseño que evite exponerlas.
